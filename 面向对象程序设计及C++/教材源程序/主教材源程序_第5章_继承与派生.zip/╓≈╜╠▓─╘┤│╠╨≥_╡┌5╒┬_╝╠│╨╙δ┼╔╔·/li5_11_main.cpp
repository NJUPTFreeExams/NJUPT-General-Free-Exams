//li5_11_main.cpp
#include <iostream>
#include <iomanip>
#include "li5_11_person.h"
using namespace std;

const int SUM = 5;			//ѧ������

class Group
{
protected:
	PostgraduateOnJob st[SUM];
	int sum;
public:
	Group( );
	void Input( );
	void SortByID( );
	void Output( );
};
Group::Group( )
{
	sum = SUM;
}
void Group::Input( )
{
	int i;
	for ( i=0; i<sum ; i++ )
	{
		st[i].Input( );
	}
}
void Group::SortByID( )
{
	int index, i, k;
	PostgraduateOnJob temp;
	for ( k=0 ; k<sum-1 ; k++ )
	{
		index = k;
		for ( i=k+1 ; i<sum ; i++ )
			if ( st[i].GetID( ) < st[index].GetID( ) )
				index = i;
		if ( index != k )
		{
			temp = st[index];
			st[index] = st[k];
			st[k] = temp;
		}
	}
}
void Group::Output( )
{
	int i;
	cout << endl << "ѧ����Ϣ��" << endl;
	cout << "���   ����   �Ա�   ר ҵ   �о�����   ְ��" << endl;
	for ( i=0; i<sum ; i++ )
	{
		cout << st[i].GetID( )  << setw(8) << st[i].GetName( )  << setw(7) << st[i].GetSex( )
			<< setw(8) << st[i].GetSpeciality( )  << setw(11) << st[i].GetResearchTopic( )
			<< setw(7) << st[i].GetAcademicTitle( ) << endl;
	}
}

int main( )
{
	Group g1;
	g1.Input( );
	g1.SortByID( );
	g1.Output( );
	return 0;
}
