//li5_11_person.cpp
#include "li5_11_person.h"

//Person��ĺ���ʵ��
Person::Person( string id, string na, string se )
{
	ID = id;
	name = na;
	sex = se;
}
void Person::Input( )
{
	cout << "��������Ϣ\n";
	cout << "��  �ţ�";
	cin >> ID;
	cout << "��  ����";
	cin >> name ;
	cout << "�Ա�(��/Ů)��";
	cin >> sex;
}
string Person::GetID( )
{
	return ID;
}
string Person::GetName( )
{
	return name;
}
string Person::GetSex( )
{
	return sex;
}

//Student��ĺ���ʵ��
Student::Student( string id, string na, string se, string spec ): Person( id, na, se )
{
	speciality = spec;
}
void Student::Input( )
{
	Person::Input( );
	cout << "ר  ҵ��";
	cin >> speciality;
}
string Student::GetSpeciality( )
{
	return speciality;
}

//Graduate��ĺ���ʵ��
Graduate::Graduate( string id, string na, string se, string spec, string rese ):  Person( id, na, se ),  Student( id, na, se, spec)
{
	researchTopic = rese;
}
void Graduate::Input( )
{
	Student::Input( );
	cout << "�о����⣺";
	cin >> researchTopic;
}
string Graduate::GetResearchTopic( )
{
	return researchTopic;
}

//Teacher��ĺ���ʵ��
Teacher::Teacher(  string id, string na, string se, string title ): Person( id, na, se )
{
	academicTitle = title;
}
void Teacher::Input( )
{
	Person::Input( );
	cout << "ְ  �ƣ�";
	cin >> academicTitle;
}
string Teacher::GetAcademicTitle( )
{
	return academicTitle;
}

//PostgraduateOnJob��ĺ���ʵ��
PostgraduateOnJob::PostgraduateOnJob( string id, string na, string se, string spec, string rese, string title ): Person( id, na, se ), Student( id, na, se, spec), Graduate( id, na, se, spec, rese), Teacher( id, na, se, title )
{
	;
}
void PostgraduateOnJob::Input( )
{
	Graduate::Input( );
	cout << "ְ  �ƣ�";
	cin >> academicTitle;
}
