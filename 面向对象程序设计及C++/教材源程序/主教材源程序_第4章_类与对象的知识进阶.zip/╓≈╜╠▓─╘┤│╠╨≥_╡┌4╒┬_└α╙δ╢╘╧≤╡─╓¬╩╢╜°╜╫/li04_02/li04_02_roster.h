#include<iostream>
#include<string>
#include"li03_09.h"
using namespace std;
class Croster
{
private:
	string name;
	CDate birthday;

public:
	Croster(string na, int y, int m, int d);
	void Display();
	~Croster();
};
