#include"li04_02_roster.h"
int main()
{
	Croster stuA("����", 2001, 1 ,29 );
	stuA.Display();
	return 0;
}