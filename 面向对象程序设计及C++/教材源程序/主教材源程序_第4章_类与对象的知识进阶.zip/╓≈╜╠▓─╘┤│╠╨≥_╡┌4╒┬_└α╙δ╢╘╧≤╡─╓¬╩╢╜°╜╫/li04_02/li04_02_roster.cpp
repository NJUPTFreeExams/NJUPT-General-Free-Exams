#include"li04_02_roster.h"
Croster::Croster(string na, int y, int m, int d)//:birthday(y, m, d) 
{
	 cout<<"Croster constructor called.\n";
	 name = na;
}

void Croster::Display()
{
	cout << name << endl;
	birthday.Display();
}
Croster::~Croster()
{
	cout<<"Croster deconstructor called.\n";
}