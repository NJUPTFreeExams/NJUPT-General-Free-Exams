#ifndef _SUBJECT
#define _SUBJECT
#include<iostream>
#include<string>
using namespace std;
class Student;
class Subject
{
		int score[3];
		const int SMath,SEng,SCpp;
public:
		Subject();
		Subject( int math,int eng ,int cpp );
		void Display()const;   
		void Input();
		void Insert();
		void Delete();
		friend class Student;  
};
#endif