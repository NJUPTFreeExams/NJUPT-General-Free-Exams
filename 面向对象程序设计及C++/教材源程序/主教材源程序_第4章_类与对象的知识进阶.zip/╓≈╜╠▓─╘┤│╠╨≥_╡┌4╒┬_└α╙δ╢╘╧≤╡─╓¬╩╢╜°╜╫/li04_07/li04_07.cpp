#include"li04_07.h"
Croster::Croster(string na, int m, double s ):name(na),
Math(m), Score(s)
{
	GPA = Math/100.0*Score;        //���㼨��
}
double Croster::GetGPA() const               
{	
	return GPA;
}
/*void Croster::Display()
{
	cout << "This is void Display()." << endl;
	cout << name << "get " << Math << endl;
	cout << "Your GPA is " << GetGPA() << endl;
}*/
void Croster::Display() const
{
	cout << "This is void Display() const." << endl;
	cout << name << "get " << Math << endl;
	cout << "Your GPA is " << GetGPA() << endl;
}
