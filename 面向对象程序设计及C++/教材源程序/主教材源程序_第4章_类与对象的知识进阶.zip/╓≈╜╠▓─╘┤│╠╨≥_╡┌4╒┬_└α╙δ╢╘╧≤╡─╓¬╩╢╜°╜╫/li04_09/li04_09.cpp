#include"li04_09.h"
CDate::CDate( int y , int m , int d ) : Date_Year(y), Date_Month(m), Date_Day(d)
{}
Croster::Croster(string na, double G  ):name(na),GPA(G)
{}
void Croster::PrintReport(const CDate &date) const 
{
	cout << name << "ͬѧ��ѧ�ڻ�ü���Ϊ��" << GPA <<endl;
	cout << date.Date_Year << "-" << date.Date_Month << "-" << date.Date_Day;
    cout << endl;
}
 