#include"li04_10_CDate.h"
CDate::CDate( int y , int m , int d ) : Date_Year(y), Date_Month(m), Date_Day(d)
{}
