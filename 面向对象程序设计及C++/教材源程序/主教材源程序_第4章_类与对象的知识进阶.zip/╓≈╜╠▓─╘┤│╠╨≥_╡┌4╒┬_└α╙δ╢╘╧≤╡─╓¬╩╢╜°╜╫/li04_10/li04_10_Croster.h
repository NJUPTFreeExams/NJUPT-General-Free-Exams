#include<iostream>
#include<string>
using namespace std;
class CDate;
class Croster
{
private:
	string name;
	double GPA;                     //����
public:
	Croster(string na="undef", double G = 3 );
	void PrintReport(const CDate &date) const ;
};
