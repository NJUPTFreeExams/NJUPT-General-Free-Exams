#include"li04_10_Croster.h"
#include"li04_10_CDate.h"
Croster::Croster(string na, double G  ):name(na),GPA(G)
{}
void Croster::PrintReport(const CDate &date) const 
{
	cout << name << "ͬѧ��ѧ�ڻ�ü���Ϊ��" << GPA <<endl;
	cout << date.Date_Year << "-" << date.Date_Month << "-" << date.Date_Day;
    cout << endl;
}