#include"li04_06_roster.h"
const double Croster::Score=3.0;  //�����þ�̬�����ݳ�Աʱʹ��
Croster::Croster(string na, int m )//, double s):Score(s)
{   
	name = na ;
	Math = m ;
}

double Croster::GetGPA()               //���㼨��
{
	GPA = Math/100.0*Score;
	return GPA;
}
void Croster::Display()
{
	cout << name << "get " << Math << endl;
	cout << "Your GPA is " << GetGPA() << endl;
}
