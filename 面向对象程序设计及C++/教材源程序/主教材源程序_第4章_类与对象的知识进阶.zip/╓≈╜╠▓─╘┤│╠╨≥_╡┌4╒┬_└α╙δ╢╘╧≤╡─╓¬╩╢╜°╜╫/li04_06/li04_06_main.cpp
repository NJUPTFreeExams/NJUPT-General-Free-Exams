#include"li04_06_roster.h"
int main()
{
	Croster stu_A("����", 92);
	stu_A.Display();
	return 0;
}