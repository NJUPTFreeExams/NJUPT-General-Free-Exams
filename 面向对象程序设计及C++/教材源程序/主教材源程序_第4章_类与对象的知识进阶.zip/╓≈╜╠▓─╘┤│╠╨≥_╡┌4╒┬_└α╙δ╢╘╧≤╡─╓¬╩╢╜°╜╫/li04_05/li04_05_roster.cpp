#include"li04_05_roster.h"
Croster::Croster(string na, int m, double s ):name(na),
Math(m),Score(s)
{}
double Croster::GetGPA()               //���㼨��
{
	GPA = Math/100.0*Score;
	return GPA;
}
void Croster::Display()
{
	cout << name << "get " << Math << endl;
	cout << "Your GPA is " << GetGPA() << endl;
}

