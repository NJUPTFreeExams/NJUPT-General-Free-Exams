#include<iostream>
#include<string>
using namespace std;
class Croster
{
private:
	string name;
	int Math;
	double Score;                   //ѧ��
	double GPA;                     //����
public:
	Croster(string na="undef", int m=100, double s=3 );
	double GetGPA();               //���㼨��
	void Display();                //���
};
