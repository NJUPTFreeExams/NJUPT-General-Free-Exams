#include<iostream>
#include<string>
using namespace std;
class Croster
{
public:
	static int Count;
private:
	string name;
	int Math;
	static int Sum;
public:
	Croster(string na="undef", int m=100);
	static void Display();
};
