#include"li04_04_roster.h"
int Croster :: Count = 100 ;  //��ʼ����̬���ݳ�ԱΪ100������
int Croster :: Sum ;          //Ĭ�ϳ�ʼֵΪ0    
Croster::Croster(string na, int m):name(na),Math(m)
{ 
	cout << "��ӭ��ͬѧ" << endl ;
	Count -- ;
	Sum += Math;
}

void Croster::Display()
{
	//cout << "name: " << name <<endl;
	cout << "Sum:" << Sum << endl;
	if ( Count == 100 )
		cout << " Average = 0 " << endl ;
	else
		cout << "Average = " << Sum*1.0/(100-Count) << endl;
}

