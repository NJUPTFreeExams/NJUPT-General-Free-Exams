#include"04_01.h"
int main( )
{
	B  obj;
	return 0;
}
