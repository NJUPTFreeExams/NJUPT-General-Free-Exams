#include"li04_03_roster.h"
int Croster :: Count = 100;                //��ʼ����̬���ݳ�Ա
Croster::Croster(string na, int m, int e):name(na),Math(m),English(e)
{ 
	cout << "��ӭ��ͬѧ" << endl ;
	Sum = Math + English ;
	Count -- ;
}

void Croster::Display()
{
	cout << name << endl;
	cout << "Math:" << Math << endl;
	cout << "English:" << English << endl;
	cout << "Sum:" << Sum << endl;
}
int Croster::Cumulation()
{
	Sum = Math + English ;
	return Sum;
}