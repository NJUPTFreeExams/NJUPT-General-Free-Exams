#include"li04_03_roster.h"
int main()
{
	cout << "Number of Remainder = " << Croster::Count << endl;
	Croster list[3];
	cout << "Number of Remainder = " << list[1].Count << endl;
	Croster stu_A;
	cout << "Number of Remainder = " << stu_A.Count << endl;
	cout << "Number of Remainder = " << Croster::Count << endl;
	return 0;
}
