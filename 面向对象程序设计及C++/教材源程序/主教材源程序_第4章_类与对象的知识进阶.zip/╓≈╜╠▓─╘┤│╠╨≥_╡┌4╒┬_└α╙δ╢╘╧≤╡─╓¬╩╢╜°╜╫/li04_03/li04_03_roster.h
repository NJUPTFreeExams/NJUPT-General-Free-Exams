#include<iostream>
#include<string>
using namespace std;
class Croster
{
public:
	static int Count;
private:
	string name;
	int Math;
	int English;
	int Sum;
public:
	Croster(string na="undef", int m=100, int e=100);
	void Display();
	int Cumulation();
};
