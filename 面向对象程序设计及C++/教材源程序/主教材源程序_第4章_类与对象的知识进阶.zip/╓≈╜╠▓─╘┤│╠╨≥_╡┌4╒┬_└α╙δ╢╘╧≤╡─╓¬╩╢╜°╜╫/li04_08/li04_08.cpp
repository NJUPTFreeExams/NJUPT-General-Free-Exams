#include"li04_08.h"
Croster::Croster(string na, int m, double s ):name(na),Math(m),Score(s)
{
	GPA = Math/100.0*Score;
}
double Croster::GetGPA() const               //���㼨��
{	
	return GPA;
}
void Croster::Display()const
{
	cout << "This is void Display() const." << endl;
	cout << name << "get " << Math << endl;
	cout << "Your GPA is " << GetGPA() << endl;
}
