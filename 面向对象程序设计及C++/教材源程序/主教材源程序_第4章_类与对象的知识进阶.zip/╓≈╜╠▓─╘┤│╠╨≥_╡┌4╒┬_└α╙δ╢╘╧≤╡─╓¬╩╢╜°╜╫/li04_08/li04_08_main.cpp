#include"li04_08.h"
/*bool Equal( Croster &A, Croster &B)
{  
	if ( A.GPA == B.GPA)
             return 1;
	else
		return 0;
}

bool Equal( Croster &A, Croster &B)    //����Ԫ����ʱ��Equal����
{  
	if ( A.GetGPA( ) == B.GetGPA( ))
             return 1;
	else
		return 0;
}*/
int main()
{
	Croster stu_A("��÷", 96, 3), stu_B("����", 98, 3);
	if (Equal( stu_A,  stu_B ))
		cout<<"GPA is the same!\n";
	else 
		cout<<"GPA is not the same!\n";
	return 0;
}
