class CDate
{
public:
	int Date_Year;
	int Date_Month;
	int Date_Day;
};

