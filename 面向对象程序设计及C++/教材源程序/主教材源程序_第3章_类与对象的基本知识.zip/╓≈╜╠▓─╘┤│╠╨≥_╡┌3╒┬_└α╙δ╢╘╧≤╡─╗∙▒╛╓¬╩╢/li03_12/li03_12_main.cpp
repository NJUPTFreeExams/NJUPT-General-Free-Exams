#include "li03_11.h"
int main()
{
	CMessage Mes1;
	CMessage Mes2(Mes1);
	
	Mes1.show();
	Mes2.show();

	Mes1.modify();
	Mes1.show();
	Mes2.show();
	
	return 0;
}

