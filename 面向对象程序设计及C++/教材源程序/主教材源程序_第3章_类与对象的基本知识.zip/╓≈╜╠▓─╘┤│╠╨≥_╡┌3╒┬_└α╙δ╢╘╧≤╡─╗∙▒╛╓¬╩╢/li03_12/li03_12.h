#include<iostream>
#include<cstring>
using namespace std;

class CMessage
{
private:
	char* pmessage;
public:
	CMessage(const char* text = "�й�һ��Ҳ������!")
	{   		
		pmessage = new char[strlen(text) + 1];
		strcpy_s(pmessage, strlen(text) + 1 , text);
	}
	CMessage(const CMessage &oMes )
	{
		size_t len = strlen(oMes.pmessage) + 1;
		pmessage = new char[len];
		strcpy_s(pmessage, len , oMes.pmessage);
	}
	void modify()
	{
		strcpy_s(pmessage,sizeof("�Ұ����"),"�Ұ����");
	}
	void show()
	{
		cout << pmessage <<endl;
	}
	~CMessage();
	
};
CMessage::~CMessage()
{
	cout << "Destructor called.\n";
	delete[] pmessage;
}
