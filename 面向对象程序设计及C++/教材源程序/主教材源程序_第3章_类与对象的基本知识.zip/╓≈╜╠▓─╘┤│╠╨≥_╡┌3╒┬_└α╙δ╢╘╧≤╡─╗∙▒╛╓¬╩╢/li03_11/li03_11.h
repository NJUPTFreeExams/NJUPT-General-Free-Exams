#include<iostream>
#include<cstring>
using namespace std;

class CMessage
{
private:
	char* pmessage;
public:
	/*CMessage(const char* text = "�й�һ��Ҳ������!")
	{
		pmessage = new char[strlen(text) + 1];
		strcpy_s(pmessage, strlen(text) + 1 , text);
	}*/
	CMessage(const char* text = "�й�һ��Ҳ������!")   //���캯��
	{
		try
		{
			pmessage = new char[strlen(text) + 1]; //���붯̬�ռ�
			strcpy_s(pmessage, strlen(text) + 1 , text);
		}
		catch(bad_alloc &bad)
		{
			cout << "Memory allocation failed." << endl;
			cout << bad.what() << endl;
		}
}

	void show()
	{
		cout << pmessage <<endl;
	}
	~CMessage()
{
	cout << "Destructor called.\n";
	delete[] pmessage;
}
};
