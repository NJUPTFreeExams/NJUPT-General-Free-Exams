#include<iostream>
#include"li03_03.h"        //������ʵ�ֳ�Ա�������˴��򻻳�"li03_02.h"                            
using namespace std;
int main()
{
	CDate date1,date2;
	int age(0);

	date1.SetDate(2019,3,9);
	date2.SetDate(1999,3,9);
	age = date1.GetYear() - date2.GetYear();
	cout << "He is " << age << " years old." << endl;
	cout << "His birthday is ";
	date2.Display();
	return 0;
}
